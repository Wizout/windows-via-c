#ifndef EPOLL_SERVER_H
#define EPOLL_SERVER_H

#include <string>

class EpollServer {
public:
  EpollServer(const std::string &ip, int port)
      : MAX_EVENT_NUMBER{1024}, BUFFER_SIZE{1024}, PARALLEL_REQUEST{5}, ip{ip},
        port{port} {}

public:
  struct ServerFd {
    int epollfd;
    int sockfd;
  };

public:
  int set_nonblocking(int fd);

  // Register EPOLLIN, EPOLLET events of `fd` into epoll kernel event table that
  // indicated by `epollfd`.
  void add_fd(int epollfd, int fd, bool oneshot);

  // Reset events of `fd`. After that, system will trigger EPOLLIN event of `fd`
  // once and only once, as long as EPOLLONESHOT event has been registered on
  // `fd`.
  void reset_oneshot(int epollfd, int fd);

  // Working thread
  void worker(int epollfd, int sockfd);

  void listen();

private:
  const int MAX_EVENT_NUMBER;
  const int BUFFER_SIZE;
  const int PARALLEL_REQUEST;

  std::string ip;
  int port;
};

#endif
