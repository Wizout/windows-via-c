
#include "simple_client.h"

#include <chrono>
#include <iostream>
#include <memory>
#include <thread>

int main(int argc, char **argv) {
  if (argc <= 2) {
    std::cout << "usage: " << argv[0] << " ip port" << std::endl;
    return -1;
  }

  SimpleClient sc{argv[1], atoi(argv[2])};
  int i = 30;

  while (i--) {
    sc.send();
    std::this_thread::sleep_for(std::chrono::seconds(3));
  }

  return 0;
}
