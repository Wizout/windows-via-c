#ifndef SIMPLE_CLIENT_H
#define SIMPLE_CLIENT_H

#include <string>

class SimpleClient {
public:
  SimpleClient(const std::string &ip, int port)
      : ip{ip}, port{port}, BUFFER_SIZE{1024}, is_connected{false}, sockfd{-1} {
  }

  ~SimpleClient();

public:
  void send();

private:
  bool connect();

  std::string now_time();

private:
  const std::string ip;
  const int port;
  const int BUFFER_SIZE;

  bool is_connected;
  int sockfd;
};

#endif // SIMPLE_CLIENT_H
