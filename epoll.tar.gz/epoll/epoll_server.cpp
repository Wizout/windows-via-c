#include "epoll_server.h"

#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/epoll.h>
#include <sys/socket.h>
#include <sys/types.h>

#include <errno.h>
#include <fcntl.h>
#include <unistd.h>

#include <cassert>
#include <chrono>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <iostream>
#include <memory>
#include <thread>

int EpollServer::set_nonblocking(int fd) {
  const int old_option = fcntl(fd, F_GETFL);

  fcntl(fd, F_SETFL, old_option | O_NONBLOCK);

  return old_option;
}

void EpollServer::add_fd(int epollfd, int fd, bool oneshot) {
  epoll_event event;

  event.data.fd = fd;
  event.events = EPOLLIN | EPOLLET;

  if (oneshot)
    event.events |= EPOLLONESHOT;

  epoll_ctl(epollfd, EPOLL_CTL_ADD, fd, &event);
  set_nonblocking(fd);
}

void EpollServer::reset_oneshot(int epollfd, int fd) {
  epoll_event event;

  event.data.fd = fd;
  event.events = EPOLLIN | EPOLLET | EPOLLONESHOT;

  epoll_ctl(epollfd, EPOLL_CTL_MOD, fd, &event);
}

void EpollServer::worker(int epollfd, int sockfd) {
  std::cout << "launched a new thread on fd " << sockfd << std::endl;

  std::unique_ptr<char[]> buf = std::make_unique<char[]>(BUFFER_SIZE);
  char *buf_ptr = buf.get();
  memset(buf_ptr, 0, BUFFER_SIZE);

  // Read data on sockfd until EAGAIN is met

  while (true) {
    int ret = recv(sockfd, buf_ptr, BUFFER_SIZE - 1, 0);

    if (!ret) {
      close(sockfd);
      puts("connection closed");
      break;
    } else if (ret > 0) {
      std::cout << "received data: " << buf_ptr << std::endl;
      sleep(3);
    } else if (EAGAIN == errno) {
      reset_oneshot(epollfd, sockfd);
      puts("read later");
      break;
    }
  }

  std::cout << "thread end with fd " << sockfd << std::endl;
}

void EpollServer::listen() {
  // create a socket for listening requests

  sockaddr_in address;
  bzero(&address, sizeof address);

  address.sin_family = AF_INET;
  address.sin_port = htons(port);
  inet_pton(AF_INET, ip.c_str(), &address.sin_addr);

  int listenfd = socket(PF_INET, SOCK_STREAM, 0);
  assert(listenfd >= 0);

  int ret = bind(listenfd, (sockaddr *)&address, sizeof address);
  assert(-1 != ret);

  ret = ::listen(listenfd, PARALLEL_REQUEST);
  assert(-1 != ret);

  // create epoll

  epoll_event events[MAX_EVENT_NUMBER];
  int epollfd = epoll_create(PARALLEL_REQUEST);
  assert(-1 != ret);

  // warning: do NOT register EPOLLONESHOT event into listenfd, otherwise server
  // may handle ONE request due to the EPOLLIN events cannot be triggered by
  // following requests.

  add_fd(epollfd, listenfd, false);

  // handle requests

  while (true) {
    ret = epoll_wait(epollfd, events, MAX_EVENT_NUMBER, -1);

    if (ret < 0) {
      std::cerr << "epoll failed" << std::endl;
      break;
    }

    for (int i = 0; i < ret; ++i) {
      int sockfd = events[i].data.fd;

      // accept a new request
      if (listenfd == sockfd) {
        sockaddr_in client_address;
        socklen_t client_addrlen = sizeof client_address;

        int connect_fd =
            accept(listenfd, (sockaddr *)&client_address, &client_addrlen);

        // register EPOLLONESHOT event for each non-listening fd
        add_fd(epollfd, connect_fd, true);
      }
      // launched a thread to handle requests
      else if (events[i].events & EPOLLIN) {
        std::thread worker{&EpollServer::worker, this, epollfd, sockfd};
        worker.detach();
      }
    }
  }

  close(listenfd);
}
