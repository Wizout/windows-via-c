#include "epoll_server.h"
#include <iostream>

int main(int argc, char **argv) {
  if (argc <= 2) {
    std::cout << "usage: " << argv[0] << " listen_ip listen_port" << std::endl;
    return -1;
  }

  EpollServer es{argv[1], atoi(argv[2])};

  es.listen();

  return 0;
}
