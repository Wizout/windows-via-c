#include "simple_client.h"

#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>

#include <unistd.h>

#include <chrono>
#include <iomanip>
#include <iostream>
#include <memory>
#include <sstream>

SimpleClient::~SimpleClient() {
  if (is_connected)
    close(sockfd);
}

std::string SimpleClient::now_time() {
  std::chrono::system_clock::time_point now = std::chrono::system_clock::now();
  std::time_t tt = std::chrono::system_clock::to_time_t(now);
  std::tm *ptm = std::localtime(&tt);

  std::ostringstream oss;
  oss << std::put_time(ptm, "%Y-%m-%d %H:%M:%S");

  return oss.str();
}

void SimpleClient::send() {
  std::string str{std::to_string((uint64_t)this) + ' ' + now_time()};

  if (is_connected || connect()) {
    ::send(sockfd, str.c_str(), str.size(), 0);
    std::cout << str << std::endl;
  } else
    puts("connect failed");
}

bool SimpleClient::connect() {
  sockfd = socket(AF_INET, SOCK_STREAM, 0);
  if (sockfd < 0) {
    perror("socket error");
    return false;
  }

  sockaddr_in ser;
  ser.sin_family = AF_INET;
  ser.sin_port = htons(port);
  ser.sin_addr.s_addr = inet_addr(ip.c_str());

  socklen_t len = sizeof(sockaddr_in);
  if (::connect(sockfd, (sockaddr *)&ser, len) < 0) {
    perror("connect error");
    return false;
  }

  is_connected = true;
  return true;
}
